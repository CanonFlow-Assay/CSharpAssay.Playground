#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
assay_root="${1:-$repo_root/../CSharpAssay}"
assay_root="$(cd "$assay_root" && pwd)"
preparation_mode="${2:-}"
bootstrap_locks=false
use_qualified=false
[[ "$preparation_mode" == '--bootstrap-locks' || "$preparation_mode" == '--qualified-bootstrap-locks' ]] && bootstrap_locks=true
[[ "$preparation_mode" == '--qualified' || "$preparation_mode" == '--qualified-bootstrap-locks' ]] && use_qualified=true
if [[ $# -gt 2 || ( -n "$preparation_mode" && "$preparation_mode" != '--qualified' && "$preparation_mode" != '--bootstrap-locks' && "$preparation_mode" != '--qualified-bootstrap-locks' ) ]]; then
  echo 'Usage: prepare-assay.sh [engine-checkout] [--qualified|--bootstrap-locks|--qualified-bootstrap-locks]' >&2
  exit 64
fi
if [[ "$bootstrap_locks" == true && -n "$(git -C "$repo_root" status --porcelain --untracked-files=all)" ]]; then
  echo 'Bootstrap requires a clean disposable checkout; existing work is not committed.' >&2
  exit 65
fi
commit_bootstrap_locks() {
  local lock_message="$1"
  shift
  if [[ "$bootstrap_locks" == true ]] && ! git diff --quiet -- "$@"; then
    git -c user.name='Assay bootstrap' -c user.email='assay-bootstrap@localhost.invalid' \
      -c commit.gpgsign=false commit --only -m "$lock_message" -- "$@"
  fi
}
if [[ "$use_qualified" == true ]]; then
  (cd "$assay_root" && dotnet eng/CsAssay.Qualification/bin/Release/net11.0/CsAssay.Qualification.dll copy-qualified --destination "$repo_root/.packages")
else
  cd "$assay_root"
  assay_commit="$(git rev-parse HEAD)"
  # Keep the engine's explicit repository URL and commit. Disable SourceLink's
  # inferred nuspec branch so detached CI gets the same local package hashes.
  pack_identity=(-p:PublishRepositoryUrl=false "-p:RepositoryCommit=$assay_commit")
  mkdir -p "$repo_root/.packages"
  pack_dir=$(mktemp -d "$repo_root/.packages/engine-pack.XXXXXX")
  trap 'rm -rf -- "$pack_dir"' EXIT
  dotnet restore CSharpAssay.slnx --locked-mode
  dotnet build CSharpAssay.slnx --no-restore --configuration Release
  dotnet pack src/CsAssay.Analyzers --no-build --no-restore --configuration Release --output "$pack_dir" "${pack_identity[@]}"
  dotnet pack src/CsAssay.Runner --no-build --no-restore --configuration Release --output "$pack_dir" "${pack_identity[@]}"
  dotnet eng/CsAssay.PackageAudit/bin/Release/net11.0/CsAssay.PackageAudit.dll \
    "$repo_root/.packages/engine-provenance" "$assay_commit" "$(dotnet --version)" unsigned normalize \
    "$pack_dir/CsAssay.Analyzers.0.2.0-rc.1.nupkg" "$pack_dir/CsAssay.Tool.0.2.0-rc.1.nupkg"
  cp "$pack_dir"/*.nupkg "$repo_root/.packages/"
fi
cd "$repo_root"
export NUGET_PACKAGES="$repo_root/.packages/cache"
# Local prerelease packages change as the paired source revision changes.
# Invalidate only this checkout's generated Assay cache, never a user's cache.
rm -rf "$NUGET_PACKAGES/csassay.analyzers/0.2.0-rc.1" \
       "$NUGET_PACKAGES/csassay.tool/0.2.0-rc.1"
# Manifest restore can reuse an older same-version local-tool resolver entry.
# The qualified package-scoped executable is installed and byte-checked below.
# Bootstrap the producer graph before restoring package-only inventory consumers.
dotnet restore Assay.Workflow.slnx --force-evaluate --configfile NuGet.config
# Explicit bootstrap records changed engine-package identities before the SDK
# freshness check. Ordinary preparation still refuses dirty producer inputs.
commit_bootstrap_locks 'Record rebuilt engine packages in disposable SDK producer locks' \
  src/Assay.Workflow.Domain/packages.lock.json \
  src/Assay.Workflow.Cli/packages.lock.json \
  samples/50-decision-assistance/src/DecisionAssist.Domain/packages.lock.json \
  eng/Assay.Tooling/packages.lock.json
./eng/prepare-application-workflow.sh
# Refresh the rebuilt local package identity across every authored project.
# The subsequent all-sample and evidence gates still require locked restore.
dotnet restore AllSamples.slnx --force-evaluate --configfile NuGet.config
commit_bootstrap_locks 'Record rebuilt preview SDK packages in disposable consumer locks' \
  ':(glob)**/packages.lock.json'
if [[ "$bootstrap_locks" == true && -n "$(git status --porcelain --untracked-files=all)" ]]; then
  echo 'Bootstrap left unexpected changes; inspect this disposable checkout.' >&2
  exit 65
fi
# Lock bootstrap may have advanced HEAD after the producer build. Bind the
# tooling's informational version to that final source before qualification.
dotnet build eng/Assay.Tooling/Assay.Tooling.csproj --no-restore --configuration Release
dotnet eng/Assay.Tooling/bin/Release/net11.0/Assay.Tooling.dll install-packed-assay
echo "Prepared CsAssay 0.2.0-rc.1 packages for .NET 11."
